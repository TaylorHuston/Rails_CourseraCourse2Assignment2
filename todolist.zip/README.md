#To Do List

Second assignment for the second course in the Coursera Rails Specialization (not to be confused with the first assignment for the same course that has the exact same name)